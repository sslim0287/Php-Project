<?php
	include('Project_Header2.html');
	echo '<h1>You have successfully logout!</h1>';
?>