<?php
	include ('Project_Header.php');
?>
<style>
#site-content {
	width:100%;
	float:left;
	background-color:#ffffff;
	}
#tex{
	font-size:25px;	
}
</style>

<div id="site-content"><br></br>
<center><img src="image/about-us.jpg" alt="aboutUs" width="" height=""></center>
<br/><br/><br/><br/><br/>
<p id="tex" style='margin-left: 268px;'><strong>&nbsp &nbsp Nature of Business:</strong>&nbsp Education Site</p><br/><br/>
<p id="tex" style='margin-left: 268px;'><strong>&nbsp &nbsp Date of Incorporation:</strong> 15 April 2019</p><br/><br/>
<p id="tex" style='margin-left: 268px;'><strong>&nbsp &nbsp Name of Directors:</strong><br/><br/>&nbsp;&nbsp;&nbsp;&nbsp;
Lim Sing Seng, Tan You Sheng, Tan Wei Jian, Jeremy Yeoh Wei Hao</p><br/><br/>
<p id="tex" style='margin-left: 268px;'><strong>&nbsp &nbsp Total Staff:</strong>&nbsp 12 Person</p><br/><br/>

</div>
<?php
	include ('Project_Footer.html');
?>